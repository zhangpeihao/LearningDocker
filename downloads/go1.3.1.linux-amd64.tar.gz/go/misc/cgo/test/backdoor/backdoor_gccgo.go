// Copyright 2014 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This is the gccgo version of the stub in runtime.c.

// +build gccgo

package backdoor

func Issue7695(x1, x2, x3, x4, x5, x6, x7, x8 uintptr) {}
